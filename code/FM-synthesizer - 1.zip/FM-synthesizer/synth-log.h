
/*
	Syntherklaas FM -- Debug logging.
*/

#pragma once

#include <string>

namespace SFM
{
	void Log(const std::string &message);
}
