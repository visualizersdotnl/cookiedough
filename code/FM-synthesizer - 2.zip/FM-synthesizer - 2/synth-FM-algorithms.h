
/*
	Syntherklaas FM -- FM algorithms.
*/

#pragma once
