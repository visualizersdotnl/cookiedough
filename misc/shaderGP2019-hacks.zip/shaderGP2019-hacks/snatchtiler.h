
#pragma once

bool Snatchtiler();
